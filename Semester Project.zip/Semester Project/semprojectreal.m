%Semester Project: Cell Counting - Draft 1


%Step 1: Reading the Target Image into the Workplace

clear;
close all;
clc;

filename = input('Enter image file name (with extension): ','s');
img = imread(filename);

%View the image

figure,
imshow(img);
title('Original Image')

%Convert Into Grayscale Image

img_gray = rgb2gray(img);
figure,
imshow(img_gray);
title('Grayscale');

%Convert to Binary Version of the Image
bw = im2bw(img_gray,0.9); %0.5 is a test threshold value
%Maybe we can have the user input the threshold value per image (similar to
%how we do the file name insert)
figure,
imshow(bw);
title('Binary Image');

%Complement the Image
bw1 = imcomplement(bw);
figure,
imshow(bw1);
title('Complemented Binary Image');

%Fill holes to make solid objects
bw2 = imfill(bw1, 'holes');
figure;
imshow(bw2);
title('Filled Image');

%Filtering the Image
bw3 = bwareaopen(bw2,10);

%Finding the number of cells
cells = bwconncomp(bw2);
noofcells = cells.NumObjects

disp('The total number of cells is :')
disp(noofcells);
